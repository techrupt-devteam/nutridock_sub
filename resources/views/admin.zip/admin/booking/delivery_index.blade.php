@extends('admin.layout.master')
 
@section('content')
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        {{ $page_name." ".$title }}
       {{--  <small>advanced tables</small> --}}
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{url('/admin')}}/dashbord"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="#">Manage {{ $title }}</a></li>
        {{-- <li class="active">{{ $page_name." ".$title }}</li> --}}
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          @include('admin.layout._status_msg')
          <div class="box">
            <div class="box-header" >
              <h3 class="box-title">{{ $page_name." ".$title }}</h3>
              <?php $session_user = Session::get('user'); ?>
              @if($session_user->role=='Store')
              <a href="{{url('/admin')}}/add_deliverty_boy" class="btn btn-primary btn-xs" style="float: right;">Add Delivery Boy</a>
              @endif
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Mobile No.</th>
                  <th>Store</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  @foreach($data as $key=>$value)
                    <tr>
                      <td>
                        {{$key+1}}
                      </td>
                      <td>
                        {{$value['first_name']}}
                      </td>
                      <td>
                        {{$value['last_name']}}
                      </td>
                      <td>
                        {{$value['email']}}
                      </td>
                      <td>
                        {{$value['mobile_no']}}
                      </td>
                      <td>
                       <?php $store = \DB::table('users')->where(['id'=>$value['store_id']])->first(); ?>
                        {{(isset($store->store_name))? $store->store_name: '-'}}
                      </td>
                      <td>
                        @if($session_user->role=='Store')
                        <a href="{{url('/admin')}}/edit_deliverty_boy/{{$value['id']}}" title="Edit">
                          <i class="fa fa-edit"></i>
                        </a>
                        @endif
                        <a href="{{url('/admin')}}/view_deliverty_boy/{{$value['id']}}" title="View">
                          <i class="fa fa-eye"></i>
                        </a>
                        {{-- <a href="{{url('/admin')}}/delete_{{$url_slug}}/{{$value['id']}}" title="Delete" onclick="return confirm('Are you sure you want to delete this record?');">
                          <i class="fa fa-trash"></i>
                        </a> --}}
                      </td>
                    </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 
@endsection